#Write your code below this line 👇
# Counting number of character in the name.

print(len(input("What is your name?")))








