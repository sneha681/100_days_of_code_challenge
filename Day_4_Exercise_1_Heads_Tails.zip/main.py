#Write your code below this line 👇
#Hint: Remember to import the random module first. 🎲

import random

random_int = random.randint(0,1)

print(random_int)
if random_int ==1:
	print("Heads")
else:
	print("Tails")








