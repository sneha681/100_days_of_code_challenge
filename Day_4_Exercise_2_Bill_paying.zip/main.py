import random

# Split string method
names_string = input("Give me everybody's names, separated by a comma.\n ")
names = names_string.split(", ")
# 🚨 Don't change the code above 👆

#Write your code below this line 👇

print(names)
name_len = len(names)
print(name_len)
random_int = random.randint(0,6)
print(random_int)
final_bill = names[random_int]

print(f"{final_bill} is going to buy the meal today!")