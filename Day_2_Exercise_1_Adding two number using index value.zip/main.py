# 🚨 Don't change the code below 👇
two_digit_number = input("Type a two digit number: ")
# 🚨 Don't change the code above 👆

####################################
#Write your code below this line 👇
# use index value to add 2 numbers
a =two_digit_number[0]  
b =two_digit_number[1]
print(int(a)+int(b))






