# 🚨 Don't change the code below 👇
print("Welcome to the Love Calculator!")
name1 = input("What is your name? \n")
name2 = input("What is their name? \n")
# 🚨 Don't change the code above 👆

#Write your code below this line 👇
combine = name1 + name2

name = combine.lower()
t= name.count('t')
r= name.count('r')
u= name.count('u')
e= name.count('e')

total1 = t+r+u+e
l= name.count('l')
o= name.count('o')
v= name.count('v')
e= name.count('e')

total2 = l+o+v+e

love_score = str(total1)+str(total2)

print(love_score)