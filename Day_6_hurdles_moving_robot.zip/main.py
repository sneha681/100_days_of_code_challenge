# first hurdles code using for loop

def turn_right():
    turn_left()
    turn_left()
    turn_left()

def jump():
    move()
    turn_left()
    move()
    turn_right()
    move()
    turn_right()
    move()
    turn_left()
    
for step in range(6):
    jump()

# second code using while loop
def turn_right():
    turn_left()
    turn_left()
    turn_left()

def jump():
    move()
    turn_left()
    move()
    turn_right()
    move()
    turn_right()
    move()
    turn_left()
    
number_of_hurdles = 6
while number_of_hurdles >0:
    jump()
    number_of_hurdles -= 1
    print(number_of_hurdles)


# third code using while and if statement
def turn_right():
    turn_left()
    move()
    turn_left()
    turn_left()
    turn_left()
    move()
    

def jump():
    turn_left()
    turn_left()
    turn_left()
    move()
    

    
def jump_1():
    turn_right()
    turn_left()
    turn_left()
    turn_left()
    move()
    turn_left()
    
while not at_goal():
    if wall_in_front() and wall_on_right():
        jump_1()   
    elif front_is_clear() and right_is_clear():
        jump()
    elif front_is_clear() and wall_on_right():
        move()
        
    
        
   

    












    
   
    
     
        
    
    
    
    
       
        
    
  
    

