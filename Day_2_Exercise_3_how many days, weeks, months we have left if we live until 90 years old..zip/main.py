# 🚨 Don't change the code below 👇
age = input("What is your current age?")
# 🚨 Don't change the code above 👆

#Write your code below this line 👇
age1 =90-age
# 1year=12month
# 1year=365 days
# 1year=52weeks
month =age1*12
days=age1*365
weeks=age1*52
# Use f string below
print(f"You have {days},{weeks} weeks,and {month} months left.")








